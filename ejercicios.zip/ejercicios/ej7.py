n=327387725427

tupla = tuple(str(n))

dic = dict()
for elem in set(tupla):
    dic.update({int(elem): tupla.count(elem)})

print(dic)